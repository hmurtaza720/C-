﻿using System.ComponentModel.DataAnnotations;

namespace M_UserLogin.ViewModels
{
    public class VerifyEmailViewModel
    {
        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress]
        public string Email { get; set; }
    }
}
